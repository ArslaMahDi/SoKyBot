# VEER لتنصيب سورس تابع قناة سورس هنا https://t.me/VeerCli

